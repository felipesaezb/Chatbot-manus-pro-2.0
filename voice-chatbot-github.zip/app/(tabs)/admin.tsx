import { useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { es } from "date-fns/locale";

type Conversation = {
  id: number;
  sessionId: string;
  firstMessage: string | null;
  lastMessage: string | null;
  lastMessageAt: Date;
  messageCount: number;
  createdAt: Date;
};

type Message = {
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  messageType: "text" | "voice";
  timestamp: Date;
};

export default function AdminScreen() {
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);

  // Obtener todas las conversaciones
  const { data: conversations, isLoading: loadingConversations } =
    trpc.admin.getConversations.useQuery(undefined, {
      refetchInterval: 5000, // Actualizar cada 5 segundos
    });

  // Obtener mensajes de la conversación seleccionada
  const { data: messages, isLoading: loadingMessages } =
    trpc.admin.getConversationMessages.useQuery(
      { conversationId: selectedConversation! },
      {
        enabled: selectedConversation !== null,
        refetchInterval: 3000, // Actualizar cada 3 segundos
      }
    );

  const renderConversationItem = ({ item }: { item: Conversation }) => {
    const isSelected = selectedConversation === item.id;
    const preview = item.firstMessage || item.lastMessage || "Sin mensajes";
    const truncatedPreview = preview.length > 60 ? preview.substring(0, 60) + "..." : preview;

    return (
      <TouchableOpacity
        onPress={() => setSelectedConversation(item.id)}
        className={`p-4 border-b border-border ${isSelected ? "bg-primary/10" : "bg-background"}`}
      >
        <View className="flex-row justify-between items-start mb-1">
          <Text className="text-sm font-semibold text-foreground">
            Conversación #{item.id}
          </Text>
          <Text className="text-xs text-muted">
            {format(new Date(item.lastMessageAt), "dd MMM, HH:mm", { locale: es })}
          </Text>
        </View>
        <Text className="text-sm text-muted mb-1" numberOfLines={2}>
          {truncatedPreview}
        </Text>
        <Text className="text-xs text-muted">{item.messageCount} mensajes</Text>
      </TouchableOpacity>
    );
  };

  const renderMessageItem = ({ item }: { item: Message }) => {
    const isUser = item.role === "user";

    return (
      <View
        className={`mb-3 ${isUser ? "items-end" : "items-start"}`}
        style={{ paddingHorizontal: 12 }}
      >
        <View
          className={`max-w-[75%] rounded-2xl px-4 py-2 ${
            isUser ? "bg-primary" : "bg-surface"
          }`}
        >
          <Text className={`text-sm ${isUser ? "text-white" : "text-foreground"}`}>
            {item.content}
          </Text>
          <View className="flex-row items-center justify-end mt-1 gap-1">
            {item.messageType === "voice" && (
              <Text className={`text-xs ${isUser ? "text-white/70" : "text-muted"}`}>
                🎤
              </Text>
            )}
            <Text className={`text-xs ${isUser ? "text-white/70" : "text-muted"}`}>
              {format(new Date(item.timestamp), "HH:mm")}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  if (loadingConversations) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color="#1869ea" />
        <Text className="text-muted mt-4">Cargando conversaciones...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="flex-1">
      <View className="flex-1 flex-row">
        {/* Lista de conversaciones (izquierda) */}
        <View className="w-1/3 border-r border-border">
          <View className="p-4 border-b border-border bg-surface">
            <Text className="text-lg font-bold text-foreground">Bandeja de Entrada</Text>
            <Text className="text-sm text-muted mt-1">
              {conversations?.length || 0} conversaciones
            </Text>
          </View>
          <FlatList
            data={conversations || []}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderConversationItem}
            ListEmptyComponent={
              <View className="p-8 items-center">
                <Text className="text-muted text-center">
                  No hay conversaciones aún.{"\n"}
                  Las conversaciones aparecerán aquí cuando los usuarios interactúen con el chatbot.
                </Text>
              </View>
            }
          />
        </View>

        {/* Vista de mensajes (derecha) */}
        <View className="flex-1">
          {selectedConversation === null ? (
            <View className="flex-1 items-center justify-center p-8">
              <Text className="text-muted text-center text-base">
                Selecciona una conversación para ver los mensajes
              </Text>
            </View>
          ) : loadingMessages ? (
            <View className="flex-1 items-center justify-center">
              <ActivityIndicator size="large" color="#1869ea" />
            </View>
          ) : (
            <>
              <View className="p-4 border-b border-border bg-surface">
                <Text className="text-lg font-bold text-foreground">
                  Conversación #{selectedConversation}
                </Text>
                <Text className="text-sm text-muted mt-1">
                  {messages?.length || 0} mensajes
                </Text>
              </View>
              <ScrollView className="flex-1 bg-background" contentContainerStyle={{ paddingVertical: 16 }}>
                {messages?.map((message) => (
                  <View key={message.id}>
                    {renderMessageItem({ item: message })}
                  </View>
                ))}
              </ScrollView>
            </>
          )}
        </View>
      </View>
    </ScreenContainer>
  );
}
