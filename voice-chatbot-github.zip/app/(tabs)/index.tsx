import { View, FlatList, TouchableOpacity, Text, StyleSheet, Platform, Alert, KeyboardAvoidingView } from "react-native";
import { Pressable } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import Svg, { Path } from "react-native-svg";
import { ScreenContainer } from "@/components/screen-container";
import { MessageBubble } from "@/components/message-bubble";
import { ChatInput, ChatInputRef } from "@/components/chat-input";
import { VoiceButton } from "@/components/voice-button";
import { WhatsAppVoiceRecorder } from "@/components/whatsapp-voice-recorder";
import { AudioWaveVisualizer } from "@/components/audio-wave-visualizer";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useChat } from "@/hooks/use-chat";
import { useColors } from "@/hooks/use-colors";
import { useAudioRecorderWeb } from "@/hooks/use-audio-recorder-web";
import { trpc } from "@/lib/trpc";
import { useState, useRef, useEffect } from "react";
import { useRouter } from "expo-router";
import { io, Socket } from "socket.io-client";
import {
  useAudioRecorder,
  useAudioPlayer,
  setAudioModeAsync,
  requestRecordingPermissionsAsync,
  RecordingPresets,
} from "expo-audio";
import { Audio } from "expo-av";
import * as FileSystem from "expo-file-system/legacy";

export default function ChatScreen() {
  const colors = useColors();
  const { messages, settings, isLoading, setIsLoading, addMessage, addMessageWithForm, updateMessagePlayingState, updateMessageReadStatus, sessionId } =
    useChat();
  const saveUserDataMutation = trpc.chat.saveUserData.useMutation();
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordingStartTime, setRecordingStartTime] = useState<number | null>(null);
  const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);
  const [hasText, setHasText] = useState(false);
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef<FlatList>(null);
  const chatInputRef = useRef<ChatInputRef>(null);
  const durationIntervalRef = useRef<any>(null);
  
  const router = useRouter();
  const socketRef = useRef<Socket | null>(null);
  const inactivityTimerRef = useRef<any>(null);
  const closeTimerRef = useRef<any>(null);
  const [inactivityWarningShown, setInactivityWarningShown] = useState(false);

  // Configurar WebSocket
  useEffect(() => {
    const apiUrl = process.env.EXPO_PUBLIC_API_URL || "http://127.0.0.1:3000";
    const socket = io(apiUrl, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5,
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("[websocket] Conectado al servidor");
      // Unirse a la sala de la conversación
      socket.emit("join-conversation", sessionId);
    });

    socket.on("new-manual-message", async (data: { message: string }) => {
      console.log("[websocket] Nuevo mensaje manual recibido:", data.message);
      
      // Agregar el mensaje del admin al chat
      const messageId = await addMessage(data.message, "bot");
      
      // Reproducir sonido de notificación
      try {
        const { sound } = await Audio.Sound.createAsync(
          require("@/assets/sounds/notification.mp3"),
          { shouldPlay: true, volume: 1.0 }
        );
        sound.setOnPlaybackStatusUpdate((status: any) => {
          if (status.isLoaded && status.didJustFinish) {
            sound.unloadAsync();
          }
        });
      } catch (error) {
        console.error("Error playing notification sound:", error);
      }
    });

    socket.on("disconnect", () => {
      console.log("[websocket] Desconectado del servidor");
    });

    socket.on("reconnect", (attemptNumber) => {
      console.log(`[websocket] Reconectado después de ${attemptNumber} intentos`);
      socket.emit("join-conversation", sessionId);
    });

    return () => {
      socket.disconnect();
    };
  }, [sessionId]);
  
  const handleSendButtonPress = () => {
    if (inputText.trim().length > 0) {
      // Verificar si es la clave de admin
      if (inputText.trim() === "Nomita1130") {
        // Limpiar el input
        chatInputRef.current?.clearInput();
        setInputText("");
        setHasText(false);
        // Navegar al panel admin
        router.push("/admin");
        return;
      }
      
      handleSendTextMessage(inputText);
      // Limpiar el input usando el ref
      chatInputRef.current?.clearInput();
      setInputText("");
      setHasText(false);
      // Mantener el foco en el input después de enviar
      setTimeout(() => chatInputRef.current?.focus(), 100);
    }
  };

  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const webRecorder = useAudioRecorderWeb();
  const player = useAudioPlayer(currentAudioUrl);
  
  // Configurar modo de audio para permitir reproducción en móvil
  useEffect(() => {
    const setupAudio = async () => {
      try {
        await Audio.setAudioModeAsync({
          playsInSilentModeIOS: true,
          staysActiveInBackground: false,
          shouldDuckAndroid: true,
        });
      } catch (error) {
        console.error("Error setting audio mode:", error);
      }
    };
    setupAudio();
  }, []);

  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const transcribeAudioMutation = trpc.chat.transcribeAudio.useMutation();
  const generateSpeechMutation = trpc.chat.generateSpeech.useMutation();
  const uploadAudioMutation = trpc.chat.uploadAudio.useMutation();

  // Configurar permisos de audio
  useEffect(() => {
    (async () => {
      await setAudioModeAsync({
        playsInSilentMode: true,
        allowsRecording: true,
      });
    })();
  }, []);

  // Auto-scroll al último mensaje
  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages.length]);

  // Sistema de inactividad
  const resetInactivityTimer = () => {
    // Limpiar timers existentes
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
    }
    if (closeTimerRef.current) {
      clearTimeout(closeTimerRef.current);
    }
    setInactivityWarningShown(false);

    // Timer de 3 minutos para mensaje de inactividad
    inactivityTimerRef.current = setTimeout(async () => {
      if (!inactivityWarningShown) {
        setInactivityWarningShown(true);
        await addMessage("¿Sigues ahí todavía?", "bot");
        
        // Timer de 1 minuto adicional para cerrar conversación
        closeTimerRef.current = setTimeout(async () => {
          await addMessage("Perfecto, cierro esta conversación por ahora 🙌 Si vuelves a escribir, lo retomamos.", "bot");
          // Aquí se podría marcar la conversación como cerrada en el backend
        }, 60000); // 1 minuto
      }
    }, 180000); // 3 minutos
  };

  // Reiniciar timer cuando el usuario envía un mensaje
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage && lastMessage.sender === "user") {
      resetInactivityTimer();
    }
  }, [messages]);

  // Iniciar timer al montar el componente
  useEffect(() => {
    resetInactivityTimer();
    return () => {
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
      }
      if (closeTimerRef.current) {
        clearTimeout(closeTimerRef.current);
      }
    };
  }, []);

  // Contador de duración de grabación
  useEffect(() => {
    if (isRecording && !isPaused) {
      durationIntervalRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
        durationIntervalRef.current = null;
      }
    }

    return () => {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [isRecording, isPaused]);

  const handleSendTextMessage = async (text: string) => {
    // Agregar mensaje del usuario
    const userMessageId = await addMessage(text, "user");
    
    // Simular delays de lectura progresivos (WhatsApp style)
    setTimeout(() => {
      updateMessageReadStatus(userMessageId, "delivered");
    }, 1000);
    
    setTimeout(() => {
      updateMessageReadStatus(userMessageId, "read");
    }, 2000);
    
    setIsLoading(true);

    try {
      // Obtener respuesta del bot
      const response = await sendMessageMutation.mutateAsync({
        message: text,
        conversationHistory: messages.slice(-10).map((msg) => ({
          role: msg.sender === "user" ? ("user" as const) : ("assistant" as const),
          content: msg.text,
        })),
        sessionId, // Agregar sessionId para verificar bot pausado
      });

      // Si el bot está pausado, no agregar mensaje del bot
      if (response.botPaused) {
        setIsLoading(false);
        return;
      }

      const botMessage =
        typeof response.message === "string"
          ? response.message
          : "Lo siento, no pude generar una respuesta.";

      // Generar audio de la respuesta si está habilitado
      let audioUrl: string | undefined;
      if (settings.autoPlayVoice) {
        try {
          const speechResult = await generateSpeechMutation.mutateAsync({
            text: botMessage,
            speed: settings.voiceSpeed,
          });
          audioUrl = speechResult.audioUrl;
        } catch (error) {
          console.error("Error generating speech:", error);
        }
      }

      // Agregar respuesta del bot (con flag de demo aceptada si aplica)
      let messageId: string;
      
      // Si el bot solicita mostrar formulario, crear mensaje con formulario
      if (response.hasFormRequest) {
        messageId = await addMessageWithForm(botMessage, "data_capture");
      } else {
        messageId = await addMessage(botMessage, "bot", audioUrl, response.acceptedDemo);
      }

      // Reproducir sonido de notificación
      try {
        const { sound } = await Audio.Sound.createAsync(
          require("@/assets/sounds/notification.mp3"),
          { shouldPlay: true, volume: 1.0 }
        );
        // Liberar el sonido después de reproducirlo
        sound.setOnPlaybackStatusUpdate((status: any) => {
          if (status.isLoaded && status.didJustFinish) {
            sound.unloadAsync();
          }
        });
      } catch (error) {
        console.error("Error playing notification sound:", error);
      }

      // Reproducir audio automáticamente si está disponible
      if (audioUrl && settings.autoPlayVoice) {
        setCurrentAudioUrl(audioUrl);
        updateMessagePlayingState(messageId, true);
        player.play();
      }
    } catch (error) {
      console.error("Error sending message:", error);
      await addMessage("Lo siento, hubo un error al procesar tu mensaje.", "bot");
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartRecording = async () => {
    console.log("[DEBUG] Iniciando grabación...");
    
    // Verificar si ya está grabando
    if (isRecording) {
      console.log("[DEBUG] Ya está grabando, ignorando...");
      return;
    }

    try {
      if (Platform.OS === "web") {
        console.log("[DEBUG] Plataforma: WEB");
        
        // Verificar si el recorder web está listo
        if (!webRecorder.isReady) {
          Alert.alert("Espera un momento", "El sistema de grabación aún está inicializando...");
          return;
        }

        await webRecorder.startRecording();
        setIsRecording(true);
        setRecordingDuration(0);
        setRecordingStartTime(Date.now());
        console.log("[DEBUG] Grabación iniciada en web");
      } else {
        console.log("[DEBUG] Plataforma: NATIVA");
        
        // Solicitar permisos
        const { granted } = await requestRecordingPermissionsAsync();
        console.log("[DEBUG] Permisos de grabación:", granted ? "CONCEDIDOS" : "DENEGADOS");
        
        if (!granted) {
          Alert.alert("Permiso denegado", "Necesitas dar permiso para usar el micrófono.");
          return;
        }

        await recorder.record();
        setIsRecording(true);
        setRecordingDuration(0);
        setRecordingStartTime(Date.now());
        console.log("[DEBUG] Grabación iniciada en nativo");
      }
    } catch (error) {
      console.error("[ERROR] Error al iniciar grabación:", error);
      Alert.alert("Error", "No se pudo iniciar la grabación. Por favor intenta de nuevo.");
    }
  };

  const handlePauseRecording = async () => {
    console.log("[DEBUG] Pausando grabación...");
    setIsPaused(true);
    
    // Nota: expo-audio no tiene pause nativo, así que solo detenemos el contador
    // La grabación continúa en segundo plano
  };

  const handleResumeRecording = async () => {
    console.log("[DEBUG] Reanudando grabación...");
    setIsPaused(false);
  };

  const handleDeleteRecording = async () => {
    console.log("[DEBUG] Eliminando grabación...");
    
    setIsRecording(false);
    setIsPaused(false);
    setRecordingDuration(0);
    setRecordingStartTime(null);
    
    // Limpiar recorder
    try {
      if (Platform.OS === "web") {
        await webRecorder.stopRecording();
      } else {
        await recorder.stop();
      }
    } catch (error) {
      console.error("[ERROR] Error al eliminar grabación:", error);
    }
  };

  const handleSendRecording = async () => {
    // DEBUG: Confirmar que la función se está llamando
    console.log("[DEBUG] handleSendRecording INICIADO - Duration:", recordingDuration);
    
    // Guardar el estado actual antes de resetear
    const currentDuration = recordingDuration;
    
    console.log("[DEBUG] Enviando grabación... isRecording:", isRecording, "duration:", currentDuration);
    
    // Verificar duración mínima
    if (currentDuration < 1) {
      console.log("[DEBUG] Audio muy corto, cancelando...");
      Alert.alert("Audio muy corto", "Por favor graba al menos 1 segundo.");
      handleDeleteRecording();
      return;
    }

    // Mostrar indicador de carga ANTES de resetear estados de grabación
    setIsLoading(true);
    
    // Resetear estados de grabación
    setIsRecording(false);
    setIsPaused(false);
    setRecordingDuration(0);
    setRecordingStartTime(null);
    
    console.log("[DEBUG] Estados reseteados, procesando audio...");

    try {
      let audioBase64: string;
      let mimeType: string;

      if (Platform.OS === "web") {
        console.log("[DEBUG] Procesando audio web...");
        
        // Detener la grabación y ESPERAR a que el blob esté listo
        console.log("[DEBUG] Llamando stopRecordingAsync...");
        await webRecorder.stopRecordingAsync();
        console.log("[DEBUG] stopRecordingAsync completado");
        
        // Pequeña espera adicional para asegurar que el blob esté procesado
        await new Promise(resolve => setTimeout(resolve, 200));
        
        // Obtener el audio en base64
        console.log("[DEBUG] Obteniendo audio base64...");
        const base64Data = await webRecorder.getAudioBase64();
        
        if (!base64Data) {
          console.error("[DEBUG] No se pudo obtener el audio base64");
          throw new Error("No se pudo capturar el audio. Por favor intenta de nuevo.");
        }

        audioBase64 = base64Data;
        mimeType = "audio/webm";
        console.log("[DEBUG] Audio web procesado. Tamaño:", audioBase64.length, "caracteres");
      } else {
        console.log("[DEBUG] Procesando audio nativo...");
        
        const uri = await recorder.stop();
        console.log("[DEBUG] URI del audio:", uri);
        
        if (typeof uri !== 'string' || !uri) {
          throw new Error("No se pudo obtener la URI del audio");
        }

        // Leer el archivo como base64
        const base64Data = await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        
        audioBase64 = base64Data;
        mimeType = "audio/m4a";
        console.log("[DEBUG] Audio nativo procesado. Tamaño:", audioBase64.length, "caracteres");
      }

      // Subir el audio a S3
      console.log("[DEBUG] Subiendo audio a S3...");
      const uploadResult = await uploadAudioMutation.mutateAsync({
        audioBase64,
        mimeType,
      });
      console.log("[DEBUG] Audio subido. URL:", uploadResult.audioUrl);

      // Transcribir el audio primero
      console.log("[DEBUG] Transcribiendo audio...");
      const transcription = await transcribeAudioMutation.mutateAsync({
        audioUrl: uploadResult.audioUrl,
      });
      console.log("[DEBUG] Transcripción:", transcription.text);

      // Agregar mensaje del usuario con el audio y transcripción
      const userMessageId = await addMessage("🎤 Mensaje de voz", "user", uploadResult.audioUrl, false, transcription.text);
      
      // Simular delays de lectura
      setTimeout(() => updateMessageReadStatus(userMessageId, "delivered"), 1000);
      setTimeout(() => updateMessageReadStatus(userMessageId, "read"), 2000);

      // Obtener respuesta del bot
      const response = await sendMessageMutation.mutateAsync({
        message: transcription.text,
        conversationHistory: messages.slice(-10).map((msg) => ({
          role: msg.sender === "user" ? ("user" as const) : ("assistant" as const),
          content: msg.text,
        })),
        sessionId, // Agregar sessionId para verificar bot pausado
      });

      // Si el bot está pausado, no agregar mensaje del bot
      if (response.botPaused) {
        setIsLoading(false);
        return;
      }

      const botMessage =
        typeof response.message === "string"
          ? response.message
          : "Lo siento, no pude generar una respuesta.";

      // Generar audio de la respuesta si está habilitado
      let botAudioUrl: string | undefined;
      if (settings.autoPlayVoice) {
        try {
          const speechResult = await generateSpeechMutation.mutateAsync({
            text: botMessage,
            speed: settings.voiceSpeed,
          });
          botAudioUrl = speechResult.audioUrl;
        } catch (error) {
          console.error("Error generating speech:", error);
        }
      }

      // Agregar respuesta del bot (con flag de demo aceptada si aplica)
      const messageId = await addMessage(botMessage, "bot", botAudioUrl, response.acceptedDemo);
      
      // Si el bot solicita mostrar formulario, agregarlo después del mensaje
      if (response.hasFormRequest) {
        await addMessageWithForm("Por favor completa tus datos:", "data_capture");
      }

      // Reproducir sonido de notificación
      try {
        const { sound } = await Audio.Sound.createAsync(
          require("@/assets/sounds/notification.mp3"),
          { shouldPlay: true, volume: 1.0 }
        );
        sound.setOnPlaybackStatusUpdate((status: any) => {
          if (status.isLoaded && status.didJustFinish) {
            sound.unloadAsync();
          }
        });
      } catch (error) {
        console.error("Error playing notification sound:", error);
      }

      // Reproducir audio automáticamente si está disponible
      if (botAudioUrl && settings.autoPlayVoice) {
        setCurrentAudioUrl(botAudioUrl);
        updateMessagePlayingState(messageId, true);
        player.play();
      }
    } catch (error: any) {
      console.error("[ERROR] Error al procesar/enviar audio:", error);
      const errorMessage = error?.message || "Error desconocido";
      console.error("[ERROR] Detalle:", errorMessage);
      Alert.alert("Error", `No se pudo enviar el mensaje de voz: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Manejar reproducción de audio al tocar una burbuja
  const handlePlayAudio = async (messageId: string, audioUrl: string) => {
    // Si ya está reproduciendo este mensaje, pausar
    const message = messages.find((m) => m.id === messageId);
    if (message?.isPlaying) {
      player.pause();
      updateMessagePlayingState(messageId, false);
      return;
    }

    // Reproducir el audio
    setCurrentAudioUrl(audioUrl);
    updateMessagePlayingState(messageId, true);
    player.play();
  };

  // Detectar cuando termina la reproducción
  useEffect(() => {
    if (!player.playing && currentAudioUrl) {
      // Buscar el mensaje que estaba reproduciendo y marcarlo como no reproduciendo
      const playingMessage = messages.find((m) => m.isPlaying);
      if (playingMessage) {
        updateMessagePlayingState(playingMessage.id, false);
      }
    }
  }, [player.playing, currentAudioUrl, messages, updateMessagePlayingState]);

  return (
    <ScreenContainer className="flex-1">
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={{ flex: 1 }}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        {/* Lista de mensajes */}
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <MessageBubble
              message={item}
              onPlayAudio={(messageId) => {
                if (item.audioUrl) {
                  handlePlayAudio(messageId, item.audioUrl);
                }
              }}
              onFormSubmit={async (data) => {
                console.log("Datos del formulario capturados:", data);
                try {
                  // Guardar datos en la base de datos
                  await saveUserDataMutation.mutateAsync({
                    sessionId,
                    userData: {
                      name: data.name,
                      email: data.email,
                      phone: data.phone,
                      countryCode: data.countryCode,
                    },
                  });
                  console.log("Datos guardados exitosamente");
                } catch (error) {
                  console.error("Error guardando datos:", error);
                }
                await addMessage(`Gracias ${data.name}! He guardado tus datos. Nos pondremos en contacto pronto.`, "bot");
              }}
            />
          )}
          contentContainerStyle={{ paddingVertical: 16, paddingHorizontal: 12 }}
          showsVerticalScrollIndicator={false}
        />

        {/* Indicador de "escribiendo..." */}
        {isLoading && (
          <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
            <View
              style={{
                alignSelf: "flex-start",
                backgroundColor: '#f8fafc',
                paddingHorizontal: 16,
                paddingVertical: 12,
                borderRadius: 20,
                borderBottomLeftRadius: 6,
                borderWidth: 1,
                borderColor: '#e2e8f0',
              }}
            >
              <Text style={{ color: '#64748b', fontSize: 14 }}>Felipe está escribiendo...</Text>
            </View>
          </View>
        )}

        {/* Input de chat - Solo texto, sin audio */}
        {true && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 16,
              paddingVertical: 14,
              gap: 10,
              backgroundColor: '#ffffff',
              borderTopWidth: 1,
              borderTopColor: '#f1f5f9',
            }}
          >
            <ChatInput
              ref={chatInputRef}
              onSendMessage={handleSendButtonPress}
              onTextChange={(hasText, text) => {
                setInputText(text);
                setHasText(hasText);
              }}
              placeholder="Escribe un mensaje..."
            />

            {/* Botón de enviar - siempre visible */}
            <TouchableOpacity
              onPress={handleSendButtonPress}
              disabled={isLoading || !hasText}
              activeOpacity={0.8}
              style={{
                width: 46,
                height: 46,
                borderRadius: 23,
                backgroundColor: hasText ? '#1869ea' : '#94a3b8',
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <IconSymbol name="paperplane.fill" size={20} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        )}
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}
