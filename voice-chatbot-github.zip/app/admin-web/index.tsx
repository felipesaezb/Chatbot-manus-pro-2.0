import { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  ActivityIndicator,
  TextInput,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { trpc } from "@/lib/trpc";
import { format, subDays, subMonths } from "date-fns";
import { es } from "date-fns/locale";

type ConversationStatus = 
  | "nuevo_lead"
  | "oportunidad"
  | "demo_agendada"
  | "propuesta_enviada"
  | "negociacion"
  | "venta_cerrada";

type Conversation = {
  id: number;
  sessionId: string;
  firstMessage: string | null;
  lastMessage: string | null;
  lastMessageAt: Date;
  messageCount: number;
  status: ConversationStatus;
  dealValue: string | null;
  notes: string | null;
  botPaused: boolean;
  userName: string | null;
  userEmail: string | null;
  userPhone: string | null;
  userCountryCode: string | null;
  mainReason: string | null;
  finalResult: string | null;
  isClosed: boolean;
  closedAt: Date | null;
  createdAt: Date;
};

type Message = {
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  messageType: "text" | "voice";
  audioUrl: string | null;
  transcription: string | null;
  timestamp: Date;
};

type DateFilter = "all" | "week" | "month" | "quarter";

const STATUS_CONFIG = {
  nuevo_lead: {
    label: "Nuevo lead",
    color: "#6B7280",
    bgColor: "#F3F4F6",
  },
  oportunidad: {
    label: "Oportunidad",
    color: "#3B82F6",
    bgColor: "#DBEAFE",
  },
  demo_agendada: {
    label: "Demo agendada",
    color: "#F59E0B",
    bgColor: "#FEF3C7",
  },
  propuesta_enviada: {
    label: "Propuesta enviada",
    color: "#10B981",
    bgColor: "#D1FAE5",
  },
  negociacion: {
    label: "Negociación",
    color: "#F97316",
    bgColor: "#FFEDD5",
  },
  venta_cerrada: {
    label: "Venta cerrada",
    color: "#059669",
    bgColor: "#A7F3D0",
  },
};

const DATE_FILTER_CONFIG = {
  all: { label: "Todo" },
  week: { label: "Última semana" },
  month: { label: "Último mes" },
  quarter: { label: "Último trimestre" },
};

export default function AdminScreen() {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [draggedConversation, setDraggedConversation] = useState<number | null>(null);
  const [dateFilter, setDateFilter] = useState<DateFilter>("all");
  const [editingDealValue, setEditingDealValue] = useState<number | null>(null);
  const [tempDealValue, setTempDealValue] = useState("");
  const [editingNotes, setEditingNotes] = useState(false);
  const [tempNotes, setTempNotes] = useState("");
  const [manualMessage, setManualMessage] = useState("");

  // Obtener conversaciones reales de la base de datos
  const { data: conversations, isLoading: loadingConversations, refetch } =
    trpc.admin.getConversations.useQuery(undefined, {
      refetchInterval: 5000,
      retry: false,
    });

  // Obtener mensajes de la conversación seleccionada
  const { data: messages, isLoading: loadingMessages, refetch: refetchMessages } =
    trpc.admin.getConversationMessages.useQuery(
      { conversationId: selectedConversation?.id! },
      {
        enabled: selectedConversation !== null,
        refetchInterval: 3000,
        retry: false,
      }
    );

  // Mutaciones para control del bot
  const toggleBotPausedMutation = trpc.admin.toggleBotPaused.useMutation();
  const sendManualMessageMutation = trpc.admin.sendManualMessage.useMutation();

  // Mutation para actualizar el status de una conversación
  const updateStatusMutation = trpc.admin.updateConversationStatus.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  // Mutation para actualizar el dealValue
  const updateDealValueMutation = trpc.admin.updateConversationDealValue.useMutation({
    onSuccess: () => {
      refetch();
      setEditingDealValue(null);
    },
  });

  // Mutation para actualizar las notas
  const updateNotesMutation = trpc.admin.updateConversationNotes.useMutation({
    onSuccess: () => {
      refetch();
      setEditingNotes(false);
      if (selectedConversation) {
        setSelectedConversation({ ...selectedConversation, notes: tempNotes });
      }
    },
  });

  const handleDragStart = (e: React.DragEvent, conversationId: number) => {
    setDraggedConversation(conversationId);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", conversationId.toString());
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, newStatus: ConversationStatus) => {
    e.preventDefault();
    
    if (draggedConversation) {
      const conversation = conversations?.find(c => c.id === draggedConversation);
      if (conversation && conversation.status !== newStatus) {
        updateStatusMutation.mutate({
          conversationId: draggedConversation,
          status: newStatus,
        });
      }
    }
    
    setDraggedConversation(null);
  };

  const handleSaveDealValue = (conversationId: number) => {
    const value = parseFloat(tempDealValue) || 0;
    updateDealValueMutation.mutate({
      conversationId,
      dealValue: value.toFixed(2),
    });
  };

  const handleSaveNotes = () => {
    if (selectedConversation) {
      updateNotesMutation.mutate({
        conversationId: selectedConversation.id,
        notes: tempNotes || null,
      });
    }
  };

  // Filtrar conversaciones por fecha
  const filterByDate = (convs: Conversation[] | undefined): Conversation[] => {
    if (!convs) return [];
    if (dateFilter === "all") return convs;

    const now = new Date();
    let cutoffDate: Date;

    switch (dateFilter) {
      case "week":
        cutoffDate = subDays(now, 7);
        break;
      case "month":
        cutoffDate = subMonths(now, 1);
        break;
      case "quarter":
        cutoffDate = subMonths(now, 3);
        break;
      default:
        return convs;
    }

    return convs.filter(conv => new Date(conv.lastMessageAt) >= cutoffDate);
  };

  const filteredConversations = filterByDate(conversations);

  // Agrupar conversaciones por status
  const conversationsByStatus = filteredConversations.reduce((acc, conv) => {
    const status = conv.status || "nuevo_lead";
    if (!acc[status]) acc[status] = [];
    acc[status].push(conv);
    return acc;
  }, {
    nuevo_lead: [],
    oportunidad: [],
    demo_agendada: [],
    propuesta_enviada: [],
    negociacion: [],
    venta_cerrada: [],
  } as Record<ConversationStatus, Conversation[]>);

  // Ordenar conversaciones por fecha (más reciente primero)
  Object.keys(conversationsByStatus).forEach((status) => {
    conversationsByStatus[status as ConversationStatus].sort((a, b) => 
      new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime()
    );
  });

  // Calcular estadísticas
  const stats = {
    total: filteredConversations.length,
    totalValue: filteredConversations.reduce((sum, conv) => sum + parseFloat(conv.dealValue || "0"), 0),
  };

  const renderConversationCard = (conversation: Conversation) => {
    const config = STATUS_CONFIG[conversation.status || "nuevo_lead"];
    const preview = conversation.firstMessage || conversation.lastMessage || "Sin mensajes";
    const truncatedPreview = preview.length > 60 ? preview.substring(0, 60) + "..." : preview;
    const dealValue = parseFloat(conversation.dealValue || "0");
    const isDragging = draggedConversation === conversation.id;
    const isEditingValue = editingDealValue === conversation.id;

    return (
      <div
        key={conversation.id}
        draggable={!isEditingValue}
        onDragStart={(e) => handleDragStart(e, conversation.id)}
        style={{
          marginBottom: 10,
          backgroundColor: isDragging ? "#F3F4F6" : "white",
          borderRadius: 8,
          padding: 14,
          border: "1px solid #E5E7EB",
          boxShadow: isDragging ? "0 4px 12px rgba(0,0,0,0.15)" : "0 1px 3px rgba(0,0,0,0.08)",
          cursor: isEditingValue ? "default" : "grab",
          opacity: isDragging ? 0.5 : 1,
          transition: "all 0.2s",
        }}
      >
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
          <div 
            style={{ flex: 1, cursor: "pointer" }}
            onClick={() => {
              if (!isEditingValue) {
                setSelectedConversation(conversation);
                setShowModal(true);
              }
            }}
          >
            <div style={{ fontSize: 14, fontWeight: 600, color: "#111827", marginBottom: 4 }}>
              Conversación #{conversation.id}
            </div>
            <div style={{ fontSize: 12, color: "#6B7280", lineHeight: 1.4 }}>
              {truncatedPreview}
            </div>
          </div>
          <div style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: "#FCD34D", marginLeft: 10, flexShrink: 0 }} />
        </div>

        {/* Footer */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10, paddingTop: 10, borderTop: "1px solid #F3F4F6" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: config.bgColor, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: config.color }}>
                {conversation.id.toString().substring(0, 1)}
              </div>
            </div>
            {isEditingValue ? (
              <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <input
                  type="number"
                  value={tempDealValue}
                  onChange={(e) => setTempDealValue(e.target.value)}
                  onBlur={() => handleSaveDealValue(conversation.id)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleSaveDealValue(conversation.id);
                    } else if (e.key === "Escape") {
                      setEditingDealValue(null);
                    }
                  }}
                  autoFocus
                  style={{
                    width: 70,
                    fontSize: 13,
                    fontWeight: 600,
                    color: "#111827",
                    border: "1px solid #3B82F6",
                    borderRadius: 4,
                    padding: "2px 6px",
                    outline: "none",
                  }}
                />
              </div>
            ) : (
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  setEditingDealValue(conversation.id);
                  setTempDealValue(dealValue.toString());
                }}
                style={{ fontSize: 13, fontWeight: 600, color: "#111827", cursor: "pointer" }}
              >
                ${dealValue.toLocaleString()}
              </div>
            )}
          </div>
          <div style={{ fontSize: 11, color: "#9CA3AF" }}>
            {format(new Date(conversation.lastMessageAt), "dd MMM", { locale: es })}
          </div>
        </div>
      </div>
    );
  };

  const renderColumn = (status: ConversationStatus) => {
    const config = STATUS_CONFIG[status];
    const convs = conversationsByStatus[status] || [];
    const totalValue = convs.reduce((sum, conv) => sum + parseFloat(conv.dealValue || "0"), 0);
    const isDropTarget = draggedConversation !== null;

    return (
      <div
        key={status}
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e, status)}
        style={{ 
          width: 280, 
          marginRight: 16, 
          display: "flex", 
          flexDirection: "column",
          minWidth: 280,
        }}
      >
        {/* Column Header */}
        <div
          style={{
            backgroundColor: isDropTarget ? config.bgColor : "white",
            borderRadius: 10,
            padding: 14,
            marginBottom: 14,
            border: `2px ${isDropTarget ? "dashed" : "solid"} ${isDropTarget ? config.color : "#E5E7EB"}`,
            transition: "all 0.2s",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>
              {config.label}
            </div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#6B7280" }}>
              {convs.length}
            </div>
          </div>
          <div style={{ fontSize: 12, color: "#6B7280" }}>
            ${totalValue.toLocaleString()}
          </div>
        </div>

        {/* Cards */}
        <div style={{ flex: 1, minHeight: 300 }}>
          {convs.map((conv) => renderConversationCard(conv))}
          {convs.length === 0 && (
            <div style={{ padding: 32, textAlign: "center" }}>
              <div style={{ color: "#D1D5DB", fontSize: 13 }}>
                No hay conversaciones
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderMessageItem = (item: Message) => {
    const isUser = item.role === "user";

    return (
      <View
        key={item.id}
        style={{
          marginBottom: 12,
          alignItems: isUser ? "flex-end" : "flex-start",
          paddingHorizontal: 16,
        }}
      >
        <View
          style={{
            maxWidth: "75%",
            borderRadius: 16,
            paddingHorizontal: 16,
            paddingVertical: 12,
            backgroundColor: isUser ? "#0052CC" : "#F3F4F6",
          }}
        >
          {item.messageType === "voice" && item.transcription && item.role === "user" ? (
            <>
              <Text style={{ fontSize: 14, lineHeight: 20, color: isUser ? "white" : "#111827", fontWeight: "600" }}>
                🎤 Audio transcrito:
              </Text>
              <Text style={{ fontSize: 14, lineHeight: 20, color: isUser ? "white" : "#111827", marginTop: 4 }}>
                {item.transcription}
              </Text>
            </>
          ) : (
            <Text style={{ fontSize: 14, lineHeight: 20, color: isUser ? "white" : "#111827" }}>
              {item.content}
            </Text>
          )}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "flex-end", marginTop: 4, gap: 4 }}>
            {item.messageType === "voice" && (
              <Text style={{ fontSize: 11, color: isUser ? "rgba(255,255,255,0.7)" : "#6B7280" }}>
                🎤
              </Text>
            )}
            <Text style={{ fontSize: 11, color: isUser ? "rgba(255,255,255,0.7)" : "#6B7280" }}>
              {format(new Date(item.timestamp), "HH:mm")}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  if (loadingConversations) {
    return (
      <ScreenContainer style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#F9FAFB" }}>
        <ActivityIndicator size="large" color="#001a3c" />
        <Text style={{ color: "#6B7280", marginTop: 16, fontWeight: "500" }}>
          Cargando conversaciones...
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <div style={{ display: "flex", flexDirection: "row", flex: 1, height: "100%" }}>
        {/* Sidebar */}
        <div style={{ width: 64, borderRight: "1px solid #E5E7EB", backgroundColor: "#001a3c" }}>
          <div style={{ padding: 16 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: "white" }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: "#001a3c" }}>
                P
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
          {/* Header */}
          <div style={{ backgroundColor: "white", borderBottom: "1px solid #E5E7EB", padding: "18px 28px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: "#001a3c" }}>
                Pipeline de Ventas
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                {/* Filtro por fecha */}
                <select
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value as DateFilter)}
                  style={{
                    backgroundColor: "#F9FAFB",
                    borderRadius: 8,
                    padding: "10px 18px",
                    fontSize: 14,
                    border: "1px solid #E5E7EB",
                    outline: "none",
                    cursor: "pointer",
                  }}
                >
                  {Object.entries(DATE_FILTER_CONFIG).map(([key, config]) => (
                    <option key={key} value={key}>
                      {config.label}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  placeholder="Buscar conversación..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  style={{
                    width: 280,
                    backgroundColor: "#F9FAFB",
                    borderRadius: 8,
                    padding: "10px 18px",
                    fontSize: 14,
                    border: "1px solid #E5E7EB",
                    outline: "none",
                  }}
                />
                <button
                  onClick={() => refetch()}
                  style={{
                    backgroundColor: "#16A34A",
                    borderRadius: 8,
                    padding: "10px 20px",
                    color: "white",
                    fontSize: 14,
                    fontWeight: 600,
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Actualizar
                </button>
              </div>
            </div>

            {/* Stats Bar */}
            <div style={{ display: "flex", alignItems: "center", gap: 18, marginTop: 14 }}>
              <div style={{ fontSize: 14, color: "#6B7280" }}>
                ${stats.totalValue.toLocaleString()}
              </div>
              <div style={{ fontSize: 14, color: "#6B7280" }}>
                {stats.total} conversaciones
              </div>
              <div style={{ fontSize: 12, color: "#9CA3AF", marginLeft: "auto" }}>
                {DATE_FILTER_CONFIG[dateFilter].label}
              </div>
            </div>
          </div>

          {/* Kanban Board */}
          <div style={{ flex: 1, overflow: "auto", padding: 20 }}>
            <div style={{ display: "flex", gap: 0, justifyContent: "flex-start" }}>
              {([
                "nuevo_lead",
                "oportunidad",
                "demo_agendada",
                "propuesta_enviada",
                "negociacion",
                "venta_cerrada"
              ] as ConversationStatus[]).map((status) => renderColumn(status))}
            </div>
          </div>
        </div>
      </div>

      {/* Modal de conversación detallada */}
      <Modal
        visible={showModal}
        animationType="slide"
        onRequestClose={() => setShowModal(false)}
      >
        <View style={{ flex: 1, backgroundColor: "white" }}>
          {/* Header del modal */}
          <View style={{ paddingHorizontal: 32, paddingVertical: 24, paddingTop: 48, backgroundColor: "#001a3c" }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <View>
                <Text style={{ color: "white", fontSize: 20, fontWeight: "700" }}>
                  Conversación #{selectedConversation?.id}
                </Text>
                <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, marginTop: 4 }}>
                  {messages?.length || 0} mensajes
                </Text>
              </View>
              <TouchableOpacity
                onPress={() => setShowModal(false)}
                style={{
                  backgroundColor: "rgba(255,255,255,0.1)",
                  borderRadius: 8,
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                }}
              >
                <Text style={{ color: "white", fontWeight: "600" }}>
                  Cerrar
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Datos del Usuario */}
          {(selectedConversation?.userName || selectedConversation?.userEmail || selectedConversation?.userPhone) && (
            <View style={{ backgroundColor: "#F0F9FF", padding: 20, borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 12 }}>
                📋 Datos Capturados
              </Text>
              <View style={{ gap: 8 }}>
                {selectedConversation?.userName && (
                  <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                    <Text style={{ fontSize: 12, color: "#6B7280" }}>Nombre:</Text>
                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#111827" }}>
                      {selectedConversation.userName}
                    </Text>
                  </View>
                )}
                {selectedConversation?.userEmail && (
                  <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                    <Text style={{ fontSize: 12, color: "#6B7280" }}>Email:</Text>
                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#111827" }}>
                      {selectedConversation.userEmail}
                    </Text>
                  </View>
                )}
                {selectedConversation?.userPhone && (
                  <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                    <Text style={{ fontSize: 12, color: "#6B7280" }}>Teléfono:</Text>
                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#111827" }}>
                      {selectedConversation.userCountryCode} {selectedConversation.userPhone}
                    </Text>
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Control del Bot */}
          <View style={{ backgroundColor: "#FFFFFF", padding: 20, borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <View>
                <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827" }}>
                  Control del Bot
                </Text>
                <Text style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>
                  {selectedConversation?.botPaused ? "🔴 Bot pausado - Modo manual activo" : "🟢 Bot activo - Respuestas automáticas"}
                </Text>
              </View>
              <TouchableOpacity
                onPress={async () => {
                  if (!selectedConversation) return;
                  const newPausedState = !selectedConversation.botPaused;
                  await toggleBotPausedMutation.mutateAsync({
                    conversationId: selectedConversation.id,
                    botPaused: newPausedState,
                  });
                  // Actualizar el estado local
                  setSelectedConversation({ ...selectedConversation, botPaused: newPausedState });
                  refetch();
                }}
                style={{
                  backgroundColor: selectedConversation?.botPaused ? "#16A34A" : "#EF4444",
                  borderRadius: 8,
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                }}
              >
                <Text style={{ color: "white", fontWeight: "600", fontSize: 13 }}>
                  {selectedConversation?.botPaused ? "▶️ Reanudar Bot" : "⏸️ Pausar Bot"}
                </Text>
              </TouchableOpacity>
            </View>
            
            {/* Campo de texto para responder manualmente (solo si el bot está pausado) */}
            {selectedConversation?.botPaused && (
              <View style={{ marginTop: 12 }}>
                <TextInput
                  value={manualMessage}
                  onChangeText={setManualMessage}
                  placeholder="Escribe una respuesta manual..."
                  multiline
                  numberOfLines={2}
                  style={{
                    backgroundColor: "#F9FAFB",
                    borderRadius: 8,
                    padding: 12,
                    fontSize: 14,
                    borderWidth: 1,
                    borderColor: "#E5E7EB",
                    minHeight: 60,
                  }}
                />
                <TouchableOpacity
                  onPress={async () => {
                    if (!selectedConversation || !manualMessage.trim()) return;
                    await sendManualMessageMutation.mutateAsync({
                      conversationId: selectedConversation.id,
                      content: manualMessage.trim(),
                    });
                    setManualMessage("");
                    refetchMessages();
                    refetch();
                  }}
                  style={{
                    backgroundColor: "#1869ea",
                    borderRadius: 8,
                    paddingHorizontal: 16,
                    paddingVertical: 10,
                    marginTop: 8,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "white", fontWeight: "600", fontSize: 13 }}>
                    Enviar Mensaje Manual
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          {/* Datos del usuario */}
          {(selectedConversation?.userName || selectedConversation?.userEmail || selectedConversation?.userPhone) && (
            <View style={{ backgroundColor: "#FFFFFF", padding: 20, borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 12 }}>
                👤 Datos del usuario
              </Text>
              {selectedConversation?.userName && (
                <View style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 12, color: "#6B7280" }}>Nombre</Text>
                  <Text style={{ fontSize: 14, color: "#111827", fontWeight: "500" }}>
                    {selectedConversation.userName}
                  </Text>
                </View>
              )}
              {selectedConversation?.userEmail && (
                <View style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 12, color: "#6B7280" }}>Email</Text>
                  <Text style={{ fontSize: 14, color: "#111827", fontWeight: "500" }}>
                    {selectedConversation.userEmail}
                  </Text>
                </View>
              )}
              {selectedConversation?.userPhone && (
                <View style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 12, color: "#6B7280" }}>Teléfono</Text>
                  <Text style={{ fontSize: 14, color: "#111827", fontWeight: "500" }}>
                    {selectedConversation.userCountryCode} {selectedConversation.userPhone}
                  </Text>
                </View>
              )}
            </View>
          )}

          {/* Tags de motivo y resultado */}
          {(selectedConversation?.mainReason || selectedConversation?.finalResult) && (
            <View style={{ backgroundColor: "#F3F4F6", padding: 20, borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 12 }}>
                🏷️ Tags
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {selectedConversation?.mainReason && (
                  <View style={{ backgroundColor: "#DBEAFE", borderRadius: 6, paddingHorizontal: 12, paddingVertical: 6 }}>
                    <Text style={{ fontSize: 12, color: "#1E40AF", fontWeight: "500" }}>
                      {selectedConversation.mainReason.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}
                    </Text>
                  </View>
                )}
                {selectedConversation?.finalResult && (
                  <View style={{ backgroundColor: "#D1FAE5", borderRadius: 6, paddingHorizontal: 12, paddingVertical: 6 }}>
                    <Text style={{ fontSize: 12, color: "#065F46", fontWeight: "500" }}>
                      {selectedConversation.finalResult.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}
                    </Text>
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Notas internas */}
          <View style={{ backgroundColor: "#F9FAFB", padding: 20, borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
            <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 8 }}>
              Notas internas
            </Text>
            {editingNotes ? (
              <View>
                <TextInput
                  value={tempNotes}
                  onChangeText={setTempNotes}
                  placeholder="Agregar notas privadas del equipo..."
                  multiline
                  numberOfLines={3}
                  style={{
                    backgroundColor: "white",
                    borderRadius: 8,
                    padding: 12,
                    fontSize: 14,
                    borderWidth: 1,
                    borderColor: "#3B82F6",
                    minHeight: 80,
                  }}
                />
                <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
                  <TouchableOpacity
                    onPress={handleSaveNotes}
                    style={{
                      backgroundColor: "#16A34A",
                      borderRadius: 6,
                      paddingHorizontal: 16,
                      paddingVertical: 8,
                    }}
                  >
                    <Text style={{ color: "white", fontWeight: "600", fontSize: 13 }}>
                      Guardar
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setEditingNotes(false);
                      setTempNotes(selectedConversation?.notes || "");
                    }}
                    style={{
                      backgroundColor: "#E5E7EB",
                      borderRadius: 6,
                      paddingHorizontal: 16,
                      paddingVertical: 8,
                    }}
                  >
                    <Text style={{ color: "#6B7280", fontWeight: "600", fontSize: 13 }}>
                      Cancelar
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <TouchableOpacity
                onPress={() => {
                  setEditingNotes(true);
                  setTempNotes(selectedConversation?.notes || "");
                }}
                style={{
                  backgroundColor: "white",
                  borderRadius: 8,
                  padding: 12,
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  minHeight: 80,
                }}
              >
                <Text style={{ fontSize: 14, color: selectedConversation?.notes ? "#111827" : "#9CA3AF" }}>
                  {selectedConversation?.notes || "Click para agregar notas..."}
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Mensajes */}
          {loadingMessages ? (
            <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
              <ActivityIndicator size="large" color="#001a3c" />
            </View>
          ) : (
            <ScrollView
              style={{ flex: 1, backgroundColor: "#F9FAFB" }}
              contentContainerStyle={{ paddingVertical: 20 }}
            >
              {messages?.map((message) => renderMessageItem(message))}
            </ScrollView>
          )}
        </View>
      </Modal>
    </ScreenContainer>
  );
}
