import { View } from "react-native";
import { useEffect, useRef } from "react";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
} from "react-native-reanimated";

interface AudioWaveVisualizerProps {
  isRecording: boolean;
  color?: string;
}

/**
 * Componente que muestra una visualización de onda de audio animada
 * mientras se está grabando
 */
export function AudioWaveVisualizer({ isRecording, color = "#0a7ea4" }: AudioWaveVisualizerProps) {
  const bars = [0, 1, 2, 3, 4];

  return (
    <View className="flex-row items-center justify-center gap-1 h-12">
      {bars.map((index) => (
        <AnimatedBar key={index} isRecording={isRecording} color={color} delay={index * 100} />
      ))}
    </View>
  );
}

interface AnimatedBarProps {
  isRecording: boolean;
  color: string;
  delay: number;
}

function AnimatedBar({ isRecording, color, delay }: AnimatedBarProps) {
  const height = useSharedValue(8);

  useEffect(() => {
    if (isRecording) {
      // Animar la barra con diferentes alturas
      height.value = withRepeat(
        withSequence(
          withTiming(32, { duration: 300 + delay, easing: Easing.inOut(Easing.ease) }),
          withTiming(12, { duration: 300 + delay, easing: Easing.inOut(Easing.ease) }),
          withTiming(24, { duration: 300 + delay, easing: Easing.inOut(Easing.ease) }),
          withTiming(8, { duration: 300 + delay, easing: Easing.inOut(Easing.ease) })
        ),
        -1, // Repetir infinitamente
        false
      );
    } else {
      // Volver a la altura mínima
      height.value = withTiming(8, { duration: 200 });
    }
  }, [isRecording, delay]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      height: height.value,
      backgroundColor: color,
    };
  });

  return <Animated.View style={[{ width: 4, borderRadius: 2 }, animatedStyle]} />;
}
