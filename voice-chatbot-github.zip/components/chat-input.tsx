import { View, TextInput, Platform, StyleSheet } from "react-native";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";
import { useState, useImperativeHandle, forwardRef, useRef } from "react";

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  placeholder?: string;
  onTextChange?: (hasText: boolean, text: string) => void;
}

export interface ChatInputRef {
  clearInput: () => void;
  focus: () => void;
}

export const ChatInput = forwardRef<ChatInputRef, ChatInputProps>(({ onSendMessage, placeholder = "Escribe un mensaje...", onTextChange }, ref) => {
  const colors = useColors();
  const [text, setText] = useState("");
  const inputRef = useRef<TextInput>(null);
  
  const handleTextChange = (newText: string) => {
    setText(newText);
    onTextChange?.(newText.trim().length > 0, newText);
  };
  
  const clearInput = () => {
    setText("");
    onTextChange?.(false, "");
  };
  
  useImperativeHandle(ref, () => ({
    clearInput,
    focus: () => inputRef.current?.focus(),
  }));

  const handleSend = () => {
    if (text.trim().length === 0) return;
    
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    
    onSendMessage(text.trim());
    setText("");
    onTextChange?.(false, "");
  };

  return (
    <View style={styles.container}>
      <TextInput
        ref={inputRef}
        value={text}
        onChangeText={handleTextChange}
        placeholder={placeholder}
        placeholderTextColor="#94a3b8"
        returnKeyType="send"
        onSubmitEditing={handleSend}
        style={styles.input}
      />
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    borderRadius: 28,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  input: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 14,
    fontSize: 15,
    color: '#1e293b',
    letterSpacing: 0.1,
  },
});
