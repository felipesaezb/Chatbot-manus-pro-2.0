import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from "react-native";
import { Picker } from "@react-native-picker/picker";

export interface DataCaptureFormProps {
  onSubmit: (data: {
    name: string;
    email: string;
    phone: string;
    countryCode: string;
  }) => Promise<void>;
  isLoading?: boolean;
}

const COUNTRY_OPTIONS = [
  { label: "Chile (+56)", value: "+56" },
  { label: "Brasil (+55)", value: "+55" },
  { label: "México (+52)", value: "+52" },
  { label: "Colombia (+57)", value: "+57" },
  { label: "Perú (+51)", value: "+51" },
  { label: "Bolivia (+591)", value: "+591" },
  { label: "Argentina (+54)", value: "+54" },
];

export function DataCaptureForm({ onSubmit, isLoading = false }: DataCaptureFormProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [countryCode, setCountryCode] = useState("+56");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!name.trim()) {
      newErrors.name = "El nombre es requerido";
    }

    if (!email.trim()) {
      newErrors.email = "El email es requerido";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = "Email inválido";
    }

    if (!phone.trim()) {
      newErrors.phone = "El teléfono es requerido";
    } else if (!/^\d{7,}$/.test(phone.replace(/\D/g, ""))) {
      newErrors.phone = "Teléfono inválido";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    try {
      await onSubmit({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        countryCode,
      });
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  return (
    <View style={{
      backgroundColor: "#FFFFFF",
      borderRadius: 12,
      padding: 16,
      marginVertical: 8,
      borderWidth: 1,
      borderColor: "#E5E7EB",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    }}>
      <Text style={{
        fontSize: 14,
        fontWeight: "600",
        color: "#111827",
        marginBottom: 12,
      }}>
        📋 Para poder ayudarte mejor, completa estos datos:
      </Text>

      {/* Campo Nombre */}
      <View style={{ marginBottom: 12 }}>
        <Text style={{
          fontSize: 12,
          fontWeight: "500",
          color: "#374151",
          marginBottom: 4,
        }}>
          Nombre *
        </Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="Tu nombre completo"
          editable={!isLoading}
          style={{
            backgroundColor: "#F9FAFB",
            borderRadius: 8,
            padding: 10,
            fontSize: 14,
            borderWidth: 1,
            borderColor: errors.name ? "#EF4444" : "#D1D5DB",
            color: "#111827",
          }}
          placeholderTextColor="#9CA3AF"
        />
        {errors.name && (
          <Text style={{ fontSize: 11, color: "#EF4444", marginTop: 4 }}>
            {errors.name}
          </Text>
        )}
      </View>

      {/* Campo Email */}
      <View style={{ marginBottom: 12 }}>
        <Text style={{
          fontSize: 12,
          fontWeight: "500",
          color: "#374151",
          marginBottom: 4,
        }}>
          Email *
        </Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder="tu@email.com"
          keyboardType="email-address"
          editable={!isLoading}
          style={{
            backgroundColor: "#F9FAFB",
            borderRadius: 8,
            padding: 10,
            fontSize: 14,
            borderWidth: 1,
            borderColor: errors.email ? "#EF4444" : "#D1D5DB",
            color: "#111827",
          }}
          placeholderTextColor="#9CA3AF"
        />
        {errors.email && (
          <Text style={{ fontSize: 11, color: "#EF4444", marginTop: 4 }}>
            {errors.email}
          </Text>
        )}
      </View>

      {/* Campo Teléfono con País */}
      <View style={{ marginBottom: 12 }}>
        <Text style={{
          fontSize: 12,
          fontWeight: "500",
          color: "#374151",
          marginBottom: 4,
        }}>
          Teléfono *
        </Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          {/* Selector de País */}
          <View style={{
            flex: 0.35,
            backgroundColor: "#F9FAFB",
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#D1D5DB",
            overflow: "hidden",
          }}>
            <Picker
              selectedValue={countryCode}
              onValueChange={setCountryCode}
              enabled={!isLoading}
              style={{ color: "#111827" }}
            >
              {COUNTRY_OPTIONS.map((option) => (
                <Picker.Item
                  key={option.value}
                  label={option.label}
                  value={option.value}
                />
              ))}
            </Picker>
          </View>

          {/* Campo Teléfono */}
          <TextInput
            value={phone}
            onChangeText={setPhone}
            placeholder="9 1234567"
            keyboardType="phone-pad"
            editable={!isLoading}
            style={{
              flex: 0.65,
              backgroundColor: "#F9FAFB",
              borderRadius: 8,
              padding: 10,
              fontSize: 14,
              borderWidth: 1,
              borderColor: errors.phone ? "#EF4444" : "#D1D5DB",
              color: "#111827",
            }}
            placeholderTextColor="#9CA3AF"
          />
        </View>
        {errors.phone && (
          <Text style={{ fontSize: 11, color: "#EF4444", marginTop: 4 }}>
            {errors.phone}
          </Text>
        )}
      </View>

      {/* Botón Enviar */}
      <TouchableOpacity
        onPress={handleSubmit}
        disabled={isLoading}
        style={{
          backgroundColor: isLoading ? "#9CA3AF" : "#1869EA",
          borderRadius: 8,
          paddingVertical: 12,
          alignItems: "center",
          marginTop: 8,
        }}
      >
        {isLoading ? (
          <ActivityIndicator color="white" />
        ) : (
          <Text style={{
            color: "white",
            fontWeight: "600",
            fontSize: 14,
          }}>
            Enviar datos
          </Text>
        )}
      </TouchableOpacity>
    </View>
  );
}
