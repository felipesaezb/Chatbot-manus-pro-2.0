import { View, Text, Pressable, Linking, TouchableOpacity, StyleSheet } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { Message } from "@/types/chat";
import { DataCaptureForm } from "@/components/data-capture-form";
import { useState } from "react";

interface MessageBubbleProps {
  message: Message;
  onPlayAudio?: (messageId: string) => void;
  onFormSubmit?: (data: { name: string; email: string; phone: string; countryCode: string }) => Promise<void>;
}

export function MessageBubble({ message, onPlayAudio, onFormSubmit }: MessageBubbleProps) {
  const colors = useColors();
  const isUser = message.sender === "user";
  
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  };

  // Detectar botones y formato Markdown
  const parseMessageContent = (text: string): Array<{ type: 'text' | 'bold', content: string } | { type: 'button', content: string, url: string }> => {
    const buttonRegex = /\[BUTTON:([^:]+):([^\]]+)\]/g;
    const parts: Array<{ type: 'text' | 'bold', content: string } | { type: 'button', content: string, url: string }> = [];
    let lastIndex = 0;
    let match;

    while ((match = buttonRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        const textBefore = text.substring(lastIndex, match.index).trim();
        parts.push(...parseMarkdown(textBefore));
      }
      parts.push({ type: 'button', content: match[1], url: match[2] });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      const textRemaining = text.substring(lastIndex).trim();
      parts.push(...parseMarkdown(textRemaining));
    }

    return parts.length > 0 ? parts : [{ type: 'text' as const, content: text }];
  };

  const parseMarkdown = (text: string): Array<{ type: 'text' | 'bold', content: string }> => {
    const boldRegex = /\*\*([^*]+)\*\*/g;
    const parts: Array<{ type: 'text' | 'bold', content: string }> = [];
    let lastIndex = 0;
    let match;

    while ((match = boldRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push({ type: 'text', content: text.substring(lastIndex, match.index) });
      }
      parts.push({ type: 'bold', content: match[1] });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      parts.push({ type: 'text', content: text.substring(lastIndex) });
    }

    return parts.length > 0 ? parts : [{ type: 'text', content: text }];
  };

  const contentParts = parseMessageContent(message.text);

  // Si el mensaje tiene formulario
  if (message.hasForm && message.formType === "data_capture") {
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const handleFormSubmit = async (data: { name: string; email: string; phone: string; countryCode: string }) => {
      setIsSubmitting(true);
      try {
        if (onFormSubmit) {
          await onFormSubmit(data);
        }
      } finally {
        setIsSubmitting(false);
      }
    };

    return (
      <View style={styles.formContainer}>
        <Text style={styles.formText}>{message.text}</Text>
        <DataCaptureForm onSubmit={handleFormSubmit} isLoading={isSubmitting} />
      </View>
    );
  }

  return (
    <View style={[styles.messageRow, isUser ? styles.messageRowUser : styles.messageRowBot]}>
      <View style={[
        styles.bubble,
        isUser ? styles.bubbleUser : styles.bubbleBot
      ]}>
        {/* Contenido del mensaje */}
        <Text style={[styles.messageText, isUser ? styles.textUser : styles.textBot]}>
          {contentParts.map((part, index) => {
            if (part.type === 'text' && part.content) {
              return <Text key={index}>{part.content}</Text>;
            } else if (part.type === 'bold' && part.content) {
              return <Text key={index} style={styles.boldText}>{part.content}</Text>;
            }
            return null;
          })}
        </Text>

        {/* Botones de acción */}
        {contentParts.map((part, index) => {
          if (part.type === 'button') {
            return (
              <TouchableOpacity
                key={index}
                onPress={() => Linking.openURL(part.url!)}
                style={styles.actionButton}
                activeOpacity={0.8}
              >
                <Text style={styles.actionButtonText}>{part.content}</Text>
              </TouchableOpacity>
            );
          }
          return null;
        })}

        {/* Hora y estado */}
        <View style={styles.metaRow}>
          <Text style={[styles.timeText, isUser ? styles.timeUser : styles.timeBot]}>
            {formatTime(message.timestamp)}
          </Text>
          {isUser && message.readStatus && (
            <Text style={[styles.checkmark, message.readStatus === "read" && styles.checkmarkRead]}>
              {message.readStatus === "sent" ? "✓" : "✓✓"}
            </Text>
          )}
          {message.audioUrl && onPlayAudio && (
            <Pressable
              onPress={() => onPlayAudio(message.id)}
              style={({ pressed }) => [styles.playButton, { opacity: pressed ? 0.6 : 1 }]}
            >
              <IconSymbol
                name={message.isPlaying ? "pause.fill" : "play.fill"}
                size={14}
                color={isUser ? "rgba(255,255,255,0.8)" : "#1869ea"}
              />
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // Layout
  messageRow: {
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  messageRowUser: {
    alignItems: 'flex-end',
  },
  messageRowBot: {
    alignItems: 'flex-start',
  },

  // Burbujas
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  bubbleUser: {
    backgroundColor: '#1869ea',
    borderRadius: 20,
    borderBottomRightRadius: 6,
  },
  bubbleBot: {
    backgroundColor: '#f8fafc',
    borderRadius: 20,
    borderBottomLeftRadius: 6,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },

  // Texto
  messageText: {
    fontSize: 15,
    lineHeight: 22,
    letterSpacing: 0.1,
  },
  textUser: {
    color: '#ffffff',
  },
  textBot: {
    color: '#1e293b',
  },
  boldText: {
    fontWeight: '600',
  },

  // Botón de acción
  actionButton: {
    marginTop: 12,
    backgroundColor: '#1869ea',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '500',
    letterSpacing: 0.2,
  },

  // Meta (hora, checkmarks)
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    gap: 6,
  },
  timeText: {
    fontSize: 11,
    letterSpacing: 0.2,
  },
  timeUser: {
    color: 'rgba(255,255,255,0.7)',
  },
  timeBot: {
    color: '#94a3b8',
  },
  checkmark: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.6)',
  },
  checkmarkRead: {
    color: '#4ade80',
  },
  playButton: {
    marginLeft: 4,
  },

  // Formulario
  formContainer: {
    marginBottom: 12,
    paddingHorizontal: 4,
    width: '100%',
  },
  formText: {
    fontSize: 15,
    lineHeight: 22,
    color: '#1e293b',
    marginBottom: 12,
  },
});
