import { View, Text, TouchableOpacity, StyleSheet, Platform } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import * as Haptics from "expo-haptics";
import { useState, useEffect, useCallback } from "react";

interface WhatsAppVoiceRecorderProps {
  isRecording: boolean;
  isPaused: boolean;
  recordingDuration: number;
  onStartRecording: () => void;
  onPauseRecording: () => void;
  onResumeRecording: () => void;
  onDeleteRecording: () => void;
  onSendRecording: () => void;
}

export function WhatsAppVoiceRecorder({
  isRecording,
  isPaused,
  recordingDuration,
  onDeleteRecording,
  onSendRecording,
}: WhatsAppVoiceRecorderProps) {
  const [waveformBars, setWaveformBars] = useState<number[]>([]);
  
  // Animación del waveform
  useEffect(() => {
    if (isRecording && !isPaused) {
      const interval = setInterval(() => {
        const bars = Array.from({ length: 30 }, () => Math.random() * 100);
        setWaveformBars(bars);
      }, 100);
      return () => clearInterval(interval);
    }
  }, [isRecording, isPaused]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  if (!isRecording) {
    return null;
  }

  // UI simplificada: solo cancelar o enviar
  return (
    <View style={[styles.container, { backgroundColor: "#1F2937" }]}>
      {/* Contador de tiempo y waveform */}
      <View style={styles.topSection}>
        <Text style={styles.duration}>{formatDuration(recordingDuration)}</Text>
        
        {/* Waveform animado */}
        <View style={styles.waveform}>
          {waveformBars.map((height, index) => (
            <View
              key={index}
              style={[
                styles.waveformBar,
                {
                  height: Math.max(4, height / 2),
                  backgroundColor: "#1869ea",
                },
              ]}
            />
          ))}
        </View>
      </View>

      {/* Solo 2 botones: Cancelar y Enviar */}
      <View style={styles.actionsContainer}>
        {/* Botón de cancelar */}
        <TouchableOpacity
          onPress={() => {
            console.log("[RECORDER] Cancel pressed");
            if (Platform.OS !== "web") {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            }
            onDeleteRecording();
          }}
          activeOpacity={0.7}
          style={[styles.actionButton, styles.cancelButton]}
        >
          <Text style={styles.cancelText}>Cancelar</Text>
        </TouchableOpacity>

        {/* Botón de enviar */}
        <TouchableOpacity
          onPress={() => {
            console.log("[RECORDER] Send pressed");
            if (Platform.OS !== "web") {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }
            onSendRecording();
          }}
          activeOpacity={0.7}
          style={[styles.actionButton, styles.sendButton]}
        >
          <IconSymbol name="paperplane.fill" size={24} color="#FFFFFF" />
          <Text style={styles.sendText}>Enviar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: "#D1D5DB",
  },
  topSection: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
    gap: 16,
  },
  duration: {
    fontSize: 18,
    fontWeight: "600",
    color: "#F3F4F6",
    minWidth: 50,
  },
  waveform: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
    height: 40,
  },
  waveformBar: {
    width: 3,
    borderRadius: 2,
    minHeight: 4,
  },
  actionsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 16,
  },
  actionButton: {
    flex: 1,
    height: 50,
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    gap: 8,
  },
  cancelButton: {
    backgroundColor: "#4B5563",
  },
  cancelText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
  sendButton: {
    backgroundColor: "#1869ea",
  },
  sendText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
});
