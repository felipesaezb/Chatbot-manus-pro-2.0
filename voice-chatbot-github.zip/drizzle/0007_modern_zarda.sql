ALTER TABLE `conversations` ADD `dealValue` decimal(10,2) DEFAULT '0.00';--> statement-breakpoint
ALTER TABLE `conversations` ADD `notes` text;