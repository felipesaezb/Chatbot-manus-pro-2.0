ALTER TABLE `messages` ADD `audioUrl` text;--> statement-breakpoint
ALTER TABLE `messages` ADD `transcription` text;