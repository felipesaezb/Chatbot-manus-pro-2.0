ALTER TABLE `conversations` ADD `userName` varchar(255);--> statement-breakpoint
ALTER TABLE `conversations` ADD `userEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `conversations` ADD `userPhone` varchar(20);--> statement-breakpoint
ALTER TABLE `conversations` ADD `userCountryCode` varchar(10);--> statement-breakpoint
ALTER TABLE `conversations` ADD `mainReason` enum('reserva_cotizacion','disponibilidad','precios_tarifas','politicas','ubicacion','pagos_comprobante','checkin_checkout','soporte_problema','otro');--> statement-breakpoint
ALTER TABLE `conversations` ADD `finalResult` enum('resuelto_bot','derivado_humano','usuario_no_respondio','cerrado_inactividad');--> statement-breakpoint
ALTER TABLE `conversations` ADD `isClosed` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `conversations` ADD `closedAt` timestamp;