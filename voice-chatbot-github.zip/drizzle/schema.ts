import { boolean, decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Conversaciones del chatbot
 * Cada conversación representa una sesión de chat con un usuario
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  /** ID de sesión único generado en el frontend */
  sessionId: varchar("sessionId", { length: 64 }).notNull().unique(),
  /** Primer mensaje del usuario (para identificar la conversación) */
  firstMessage: text("firstMessage"),
  /** Último mensaje de la conversación */
  lastMessage: text("lastMessage"),
  /** Timestamp del último mensaje */
  lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  /** Número total de mensajes en la conversación */
  messageCount: int("messageCount").default(0).notNull(),
  /** Estado de la conversación en el embudo de ventas */
  status: mysqlEnum("status", [
    "nuevo_lead",
    "oportunidad",
    "demo_agendada",
    "propuesta_enviada",
    "negociacion",
    "venta_cerrada"
  ]).default("nuevo_lead").notNull(),
  /** Valor monetario estimado del deal (en USD) */
  dealValue: decimal("dealValue", { precision: 10, scale: 2 }).default("0.00"),
  /** Notas internas privadas del equipo */
  notes: text("notes"),
  /** Indica si el bot está pausado (control manual activo) */
  botPaused: boolean("botPaused").default(false).notNull(),
  /** Datos del usuario capturados durante la conversación */
  userName: varchar("userName", { length: 255 }),
  userEmail: varchar("userEmail", { length: 320 }),
  userPhone: varchar("userPhone", { length: 20 }),
  userCountryCode: varchar("userCountryCode", { length: 10 }),
  /** Motivo principal de la conversación */
  mainReason: mysqlEnum("mainReason", [
    "reserva_cotizacion",
    "disponibilidad",
    "precios_tarifas",
    "politicas",
    "ubicacion",
    "pagos_comprobante",
    "checkin_checkout",
    "soporte_problema",
    "otro"
  ]),
  /** Resultado final de la conversación */
  finalResult: mysqlEnum("finalResult", [
    "resuelto_bot",
    "derivado_humano",
    "usuario_no_respondio",
    "cerrado_inactividad"
  ]),
  /** Indica si la conversación está cerrada */
  isClosed: boolean("isClosed").default(false).notNull(),
  /** Timestamp de cierre de la conversación */
  closedAt: timestamp("closedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Mensajes individuales dentro de cada conversación
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  /** Rol del mensaje: 'user' o 'assistant' */
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  /** Contenido del mensaje */
  content: text("content").notNull(),
  /** Tipo de mensaje: 'text' o 'voice' */
  messageType: mysqlEnum("messageType", ["text", "voice"]).default("text").notNull(),
  /** URL del audio (si es mensaje de voz) */
  audioUrl: text("audioUrl"),
  /** Transcripción del audio (si es mensaje de voz) */
  transcription: text("transcription"),
  /** Timestamp del mensaje */
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;
