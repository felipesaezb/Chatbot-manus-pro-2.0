import { useState, useRef, useCallback } from "react";
import { Platform } from "react-native";

/**
 * Hook para grabación de audio que funciona tanto en web como en móvil
 * En web usa MediaRecorder API, en móvil usa expo-audio
 */
export function useAudioRecorderWeb() {
  const [isRecording, setIsRecording] = useState(false);
  const [isReady, setIsReady] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const audioBlobRef = useRef<Blob | null>(null);
  const stopResolverRef = useRef<(() => void) | null>(null);

  const startRecording = useCallback(async () => {
    if (Platform.OS !== "web") {
      console.log("[RECORDER] Not on web, skipping MediaRecorder");
      return false;
    }

    if (!isReady || isProcessing) {
      console.log("[RECORDER] Not ready yet or processing, please wait");
      return false;
    }

    try {
      console.log("[RECORDER] Requesting microphone permission...");
      
      // Limpiar cualquier grabación anterior
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      
      audioBlobRef.current = null;
      audioChunksRef.current = [];
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100,
        } 
      });
      
      streamRef.current = stream;
      console.log("[RECORDER] Permission granted, creating MediaRecorder...");

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          console.log("[RECORDER] Audio chunk received:", event.data.size, "bytes");
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        console.log("[RECORDER] Recording stopped");
        console.log("[RECORDER] Total chunks collected:", audioChunksRef.current.length);
        
        if (audioChunksRef.current.length === 0) {
          console.error("[RECORDER] No audio chunks collected!");
          audioBlobRef.current = null;
        } else {
          const totalSize = audioChunksRef.current.reduce((sum, chunk) => sum + chunk.size, 0);
          console.log("[RECORDER] Total audio size:", totalSize, "bytes");
          
          const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm;codecs=opus" });
          console.log("[RECORDER] Blob created:", audioBlob.size, "bytes");
          audioBlobRef.current = audioBlob;
        }
        
        // Limpiar el stream
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
          streamRef.current = null;
        }
        
        setIsProcessing(false);
        
        // Resolver la promesa de stop si existe
        if (stopResolverRef.current) {
          console.log("[RECORDER] Resolving stop promise");
          stopResolverRef.current();
          stopResolverRef.current = null;
        }
      };

      mediaRecorder.onerror = (event) => {
        console.error("[RECORDER] MediaRecorder error:", event);
        setIsProcessing(false);
        if (stopResolverRef.current) {
          stopResolverRef.current();
          stopResolverRef.current = null;
        }
      };

      // Iniciar grabación con timeslice para obtener chunks frecuentes
      mediaRecorder.start(100);
      setIsRecording(true);
      console.log("[RECORDER] Recording started");
      return true;
    } catch (error) {
      console.error("[RECORDER] Error starting recording:", error);
      return false;
    }
  }, [isReady, isProcessing]);

  // Versión asíncrona que espera a que el blob esté listo
  const stopRecordingAsync = useCallback((): Promise<void> => {
    return new Promise((resolve) => {
      if (Platform.OS !== "web" || !mediaRecorderRef.current) {
        console.log("[RECORDER] No MediaRecorder to stop");
        resolve();
        return;
      }

      const recorder = mediaRecorderRef.current;
      
      if (recorder.state !== "recording") {
        console.log("[RECORDER] MediaRecorder not recording, state:", recorder.state);
        resolve();
        return;
      }

      console.log("[RECORDER] Stopping recording async...");
      setIsProcessing(true);
      setIsRecording(false);
      
      // Guardar el resolver para llamarlo en onstop
      stopResolverRef.current = resolve;
      
      // Solicitar los últimos datos antes de detener
      try {
        recorder.requestData();
      } catch (e) {
        console.log("[RECORDER] requestData failed:", e);
      }
      
      // Detener el recorder
      recorder.stop();
      
      // Timeout de seguridad por si onstop nunca se llama
      setTimeout(() => {
        if (stopResolverRef.current) {
          console.log("[RECORDER] Stop timeout reached, resolving anyway");
          stopResolverRef.current();
          stopResolverRef.current = null;
          setIsProcessing(false);
        }
      }, 3000);
    });
  }, []);

  // Versión síncrona para compatibilidad (no espera)
  const stopRecording = useCallback(() => {
    if (Platform.OS !== "web" || !mediaRecorderRef.current) {
      return;
    }

    console.log("[RECORDER] Stopping recording sync...");
    setIsRecording(false);
    
    if (mediaRecorderRef.current.state === "recording") {
      try {
        mediaRecorderRef.current.requestData();
      } catch (e) {
        console.log("[RECORDER] requestData failed:", e);
      }
      mediaRecorderRef.current.stop();
    }
  }, []);

  const getAudioBase64 = useCallback(async (): Promise<string | null> => {
    console.log("[RECORDER] getAudioBase64 called, blob:", audioBlobRef.current?.size || "null");
    
    if (!audioBlobRef.current) {
      console.error("[RECORDER] No audio blob available");
      return null;
    }

    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        const base64Data = base64.split(",")[1];
        console.log("[RECORDER] Audio converted to base64:", base64Data?.length || 0, "characters");
        resolve(base64Data || null);
      };
      reader.onerror = () => {
        console.error("[RECORDER] Error converting to base64");
        resolve(null);
      };
      reader.readAsDataURL(audioBlobRef.current!);
    });
  }, []);

  const clearAudio = useCallback(() => {
    audioBlobRef.current = null;
    audioChunksRef.current = [];
    console.log("[RECORDER] Audio cleared");
  }, []);

  return {
    isRecording,
    isReady,
    isProcessing,
    startRecording,
    stopRecording,
    stopRecordingAsync,
    getAudioBase64,
    clearAudio,
    hasAudio: audioBlobRef.current !== null,
  };
}
