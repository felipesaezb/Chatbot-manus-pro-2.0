import { useState, useEffect, useCallback, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Message, ChatSettings } from "@/types/chat";
import { trpc } from "@/lib/trpc";

const CHAT_HISTORY_KEY = "chat_history";
const CHAT_SETTINGS_KEY = "chat_settings";

const DEFAULT_SETTINGS: ChatSettings = {
  autoPlayVoice: true,
  voiceSpeed: "normal",
};

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [settings, setSettings] = useState<ChatSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(false);
  
  // Generar sessionId único para esta sesión de chat
  const sessionId = useRef(`session-${Date.now()}-${Math.random().toString(36).substring(7)}`);
  const saveConversationMutation = trpc.admin.saveConversation.useMutation();

  // Cargar configuración al iniciar (historial NO se persiste)
  useEffect(() => {
    // loadChatHistory(); // Deshabilitado: cada sesión inicia limpia
    loadSettings();
    
    // Mensaje de bienvenida automático
    const welcomeMessage: Message = {
      id: 'welcome-' + Date.now().toString(),
      text: '¡Hola! 👋 Soy Felipe, tu asistente virtual de Nomahost. ¿En qué puedo ayudarte hoy?',
      sender: 'bot',
      timestamp: Date.now(),
    };
    setMessages([welcomeMessage]);
  }, []);

  // Guardar historial cuando cambia (DESHABILITADO)
  // useEffect(() => {
  //   if (messages.length > 0) {
  //     saveChatHistory();
  //   }
  // }, [messages]);

  const loadChatHistory = async () => {
    try {
      const stored = await AsyncStorage.getItem(CHAT_HISTORY_KEY);
      if (stored) {
        setMessages(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading chat history:", error);
    }
  };

  const saveChatHistory = async () => {
    try {
      await AsyncStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(messages));
    } catch (error) {
      console.error("Error saving chat history:", error);
    }
  };

  const loadSettings = async () => {
    try {
      const stored = await AsyncStorage.getItem(CHAT_SETTINGS_KEY);
      if (stored) {
        setSettings(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading settings:", error);
    }
  };

  const saveSettings = async (newSettings: ChatSettings) => {
    try {
      await AsyncStorage.setItem(CHAT_SETTINGS_KEY, JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error("Error saving settings:", error);
    }
  };

  const addMessageWithForm = useCallback(async (text: string, formType: "data_capture") => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: "bot",
      timestamp: Date.now(),
      hasForm: true,
      formType,
    };
    
    setMessages((prev) => [...prev, newMessage]);
    return newMessage.id;
  }, []);

  const addMessage = useCallback(async (text: string, sender: "user" | "bot", audioUrl?: string, acceptedDemo?: boolean, transcription?: string) => {
    // La verificación del bot pausado ahora se hace en el servidor

    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender,
      timestamp: Date.now(),
      audioUrl,
      isPlaying: false,
      readStatus: sender === "user" ? "sent" : undefined,
    };
    
    setMessages((prev) => [...prev, newMessage]);
    
    // Guardar mensaje en la base de datos
    const isFirstMessage = messages.length === 0 && sender === "user";
    saveConversationMutation.mutate({
      sessionId: sessionId.current,
      message: {
        role: sender === "user" ? "user" : "assistant",
        content: text,
        messageType: audioUrl ? "voice" : "text",
        audioUrl,
        transcription,
      },
      isFirstMessage,
      acceptedDemo, // Pasar el flag de demo aceptada
    });
    
    return newMessage.id;
  }, [messages.length, saveConversationMutation]);

  const clearHistory = async () => {
    try {
      await AsyncStorage.removeItem(CHAT_HISTORY_KEY);
      setMessages([]);
    } catch (error) {
      console.error("Error clearing chat history:", error);
    }
  };

  const updateMessagePlayingState = useCallback((messageId: string, isPlaying: boolean) => {
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === messageId ? { ...msg, isPlaying } : { ...msg, isPlaying: false }
      )
    );
  }, []);

  const updateMessageReadStatus = useCallback((messageId: string, readStatus: "sent" | "delivered" | "read") => {
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === messageId ? { ...msg, readStatus } : msg
      )
    );
  }, []);

  return {
    messages,
    settings,
    isLoading,
    setIsLoading,
    addMessage,
    addMessageWithForm,
    updateMessagePlayingState,
    saveSettings,
    updateMessageReadStatus,
    sessionId: sessionId.current, // Exportar sessionId para usar en sendMessage
  };
}
