#!/usr/bin/env node

/**
 * Keep-Alive Script
 * Pings the server every 5 minutes to prevent it from sleeping
 * Run this in the background: node scripts/keep-alive.js &
 */

const http = require("http");

// Get the server URL from environment or use default
const SERVER_URL = process.env.KEEP_ALIVE_URL || "http://localhost:3000";
const PING_INTERVAL = 5 * 60 * 1000; // 5 minutes in milliseconds

console.log(`[Keep-Alive] Starting keep-alive service for ${SERVER_URL}`);
console.log(`[Keep-Alive] Pinging every ${PING_INTERVAL / 1000} seconds`);

function ping() {
  const url = new URL("/api/health", SERVER_URL);
  
  http.get(url, (res) => {
    const timestamp = new Date().toISOString();
    if (res.statusCode === 200) {
      console.log(`[${timestamp}] ✅ Server is alive (status: ${res.statusCode})`);
    } else {
      console.log(`[${timestamp}] ⚠️  Server responded with status: ${res.statusCode}`);
    }
  }).on("error", (err) => {
    const timestamp = new Date().toISOString();
    console.error(`[${timestamp}] ❌ Ping failed: ${err.message}`);
  });
}

// Ping immediately on start
ping();

// Then ping every 5 minutes
setInterval(ping, PING_INTERVAL);

// Handle graceful shutdown
process.on("SIGINT", () => {
  console.log("\n[Keep-Alive] Shutting down keep-alive service");
  process.exit(0);
});
