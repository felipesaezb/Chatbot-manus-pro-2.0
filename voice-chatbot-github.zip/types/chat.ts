export interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: number;
  audioUrl?: string;
  isPlaying?: boolean;
  readStatus?: "sent" | "delivered" | "read";
  hasForm?: boolean;
  formType?: "data_capture";
}

export interface ChatSettings {
  autoPlayVoice: boolean;
  voiceSpeed: "slow" | "normal" | "fast";
}

export interface UserFormData {
  name: string;
  email: string;
  phone: string;
  countryCode: string;
}
